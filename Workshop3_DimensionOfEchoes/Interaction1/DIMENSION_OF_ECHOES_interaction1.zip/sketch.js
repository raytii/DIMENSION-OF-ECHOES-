let handPose;
let video;
let hands = [];
let history = []; // Stores the historical positions of both hands for the trail effect
const TRAIL_LENGTH = 25; // Length of the ribbon tail

// Smoothed coordinates to prevent minor hand jitter and tracking noise
let smoothLeft = { x: 0, y: 0 };
let smoothRight = { x: 0, y: 0 };

function preload() {
  // Load the hand tracking model
  handPose = ml5.handPose();
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  // Start continuous hand detection
  handPose.detectStart(video, (results) => {
    hands = results;
  });
  
  // Initialize smoothed coordinates to the center of the screen
  smoothLeft = { x: width / 2 - 100, y: height / 2 };
  smoothRight = { x: width / 2 + 100, y: height / 2 };
  
  // Use HSB mode for easier and smoother color wheel cycling
  colorMode(HSB, 360, 100, 100, 100); 
}

function draw() {
  // 1. Create a semi-transparent black background to generate a motion blur / fading effect
  blendMode(BLEND);
  background(0, 0, 0, 15); 

  // 2. Identify hands and update their smoothed positions
  updateHandPositions();

  // 3. Store the current smoothed positions into the history array
  history.push({
    left: { x: smoothLeft.x, y: smoothLeft.y },
    right: { x: smoothRight.x, y: smoothRight.y }
  });

  // Maintain the maximum length of the history array
  if (history.length > TRAIL_LENGTH) {
    history.shift();
  }

  // 4. Render the generative glowing ribbon
  drawNeuralRibbon();
}

function updateHandPositions() {
  // Mirror correction: ml5's 'Left' label often appears on the right in a mirrored video feed
  let rawLeft = hands.find(h => h.handedness === 'Right'); 
  let rawRight = hands.find(h => h.handedness === 'Left');

  // Use lerp (Linear Interpolation) to make the movement frictionless and silky (0.15 is the easing factor)
  if (rawLeft) {
    let tx = map(rawLeft.keypoints[8].x, 0, video.width, width, 0);
    let ty = map(rawLeft.keypoints[8].y, 0, video.height, 0, height);
    smoothLeft.x = lerp(smoothLeft.x, tx, 0.15);
    smoothLeft.y = lerp(smoothLeft.y, ty, 0.15);
  }

  if (rawRight) {
    let tx = map(rawRight.keypoints[8].x, 0, video.width, width, 0);
    let ty = map(rawRight.keypoints[8].y, 0, video.height, 0, height);
    smoothRight.x = lerp(smoothRight.x, tx, 0.15);
    smoothRight.y = lerp(smoothRight.y, ty, 0.15);
  }
}

function drawNeuralRibbon() {
  push();
  blendMode(ADD); // Enable additive blending for a glowing, neon aesthetic
  noFill();

  // Iterate through the history array to draw the connecting lines
  for (let i = 0; i < history.length - 1; i++) {
    let current = history[i];
    
    // Calculate the current hue position on the color wheel
    // frameCount * 2 controls the speed of the color cycle
    let hueValue = (frameCount * 2 + i * 5) % 360; 
    
    // Line thickness and opacity decay over time (history)
    let weight = map(i, 0, history.length, 1, 8);
    let alpha = map(i, 0, history.length, 10, 100);

    stroke(hueValue, 80, 100, alpha);
    strokeWeight(weight);

    // Set canvas context shadow for an intense neon glow effect
    drawingContext.shadowBlur = 15;
    drawingContext.shadowColor = color(hueValue, 80, 100, alpha);

    // Draw the main line between the historical left and right hand coordinates
    line(current.left.x, current.left.y, current.right.x, current.right.y);
    
    // Add decorative structural nodes at the edges for a "Cyber/Neural" feel
    if (i % 5 === 0) {
      strokeWeight(1);
      ellipse(current.left.x, current.left.y, 5);
      ellipse(current.right.x, current.right.y, 5);
    }
  }
  pop();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}