let handPose;
let video;
let hands = [];

// Physical nodes and physics history
let nodes = [];
const NUM_NODES = 25; 
let ribbonHistory = []; 
const MAX_HISTORY = 120; // Shortened history length to reserve memory for heavy rendering

let leftX = 0, leftY = 0, rightX = 0, rightY = 0;

// Iteration 2: Variables controlled by finger pinch distance
let leftRadius = 50; 
let rightGlowLayers = 20; 

function preload() {
  handPose = ml5.handPose();
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  // Initialize hand tracking
  handPose.detectStart(video, (results) => {
    hands = results;
  });

  // Initialize physical nodes at the center of the canvas
  for (let i = 0; i < NUM_NODES; i++) {
    nodes.push({ x: width / 2, y: height / 2 });
  }
  
  colorMode(HSB, 360, 100, 100, 1);
}

function draw() {
  drawStylizedBackground();

  // 1. Process complex hand gestures and update physics
  updateComplexHandInput();
  updatePhysics();

  // Record node positions for history rendering
  let currentSnap = [];
  for(let n of nodes) {
    currentSnap.push({x: n.x, y: n.y}); 
  }
  ribbonHistory.push({points: currentSnap, t: frameCount});

  if (ribbonHistory.length > MAX_HISTORY) {
    ribbonHistory.shift();
  }

  // 2. Heavy artistic rendering (Deliberately pushing system limits)
  drawHeavy3DSilk();
  drawComplexEndpoints();
  
  drawUI();
}

function drawStylizedBackground() {
  push();
  // Mirror the video feed to match user movement naturally
  translate(width, 0);
  scale(-1, 1);
  tint(0, 0, 40); 
  image(video, 0, 0, width, height);
  noTint();
  filter(GRAY); 
  fill(0, 0, 0, 0.75); // Apply a dark semi-transparent overlay for depth
  rect(0, 0, width, height);
  pop();
}

// ==========================================
// Modification 1: Complex Hand Gesture Distance Calculation
// ==========================================
function updateComplexHandInput() {
  // ml5 mirrors the handedness by default in webcam view
  let rawLeft = hands.find(h => h.handedness === 'Right'); 
  let rawRight = hands.find(h => h.handedness === 'Left');

  if (rawLeft) {
    // Extract Index finger (8) and Thumb (4) keypoints
    let ix = map(rawLeft.keypoints[8].x, 0, video.width, width, 0);
    let iy = map(rawLeft.keypoints[8].y, 0, video.height, 0, height);
    let tx = map(rawLeft.keypoints[4].x, 0, video.width, width, 0);
    let ty = map(rawLeft.keypoints[4].y, 0, video.height, 0, height);

    leftX = lerp(leftX, ix, 0.15);
    leftY = lerp(leftY, iy, 0.15);
    
    // Left Hand: Distance between thumb and index controls the endpoint radius
    let pinchDist = dist(ix, iy, tx, ty);
    let targetRadius = map(pinchDist, 20, 200, 15, 180); 
    leftRadius = lerp(leftRadius, targetRadius, 0.1); 
  }
  
  if (rawRight) {
    // Extract Index finger (8) and Thumb (4) keypoints
    let ix = map(rawRight.keypoints[8].x, 0, video.width, width, 0);
    let iy = map(rawRight.keypoints[8].y, 0, video.height, 0, height);
    let tx = map(rawRight.keypoints[4].x, 0, video.width, width, 0);
    let ty = map(rawRight.keypoints[4].y, 0, video.height, 0, height);

    rightX = lerp(rightX, ix, 0.15);
    rightY = lerp(rightY, iy, 0.15);
    
    // Right Hand: Distance controls the number of glow layers
    // Note: When fully spread, target layers surge, causing significant JS thread lag
    let pinchDist = dist(ix, iy, tx, ty);
    let targetLayers = map(pinchDist, 20, 200, 10, 250); 
    rightGlowLayers = lerp(rightGlowLayers, targetLayers, 0.1);
  }
}

function updatePhysics() {
  nodes[0].x = leftX;
  nodes[0].y = leftY;
  nodes[NUM_NODES - 1].x = rightX;
  nodes[NUM_NODES - 1].y = rightY;

  // Apply noise and linear interpolation to intermediate nodes for a fluid ribbon effect
  for (let i = 1; i < NUM_NODES - 1; i++) {
    let targetX = (nodes[i - 1].x + nodes[i + 1].x) / 2;
    let targetY = (nodes[i - 1].y + nodes[i + 1].y) / 2;
    let n = noise(i * 0.3, frameCount * 0.015) * 8;
    nodes[i].x = lerp(nodes[i].x, targetX, 0.2) + (n - 4);
    nodes[i].y = lerp(nodes[i].y, targetY, 0.2) + (n - 4);
  }
}

// ==========================================
// Modification 2: Over-rendered "Pseudo-3D" Silk
// ==========================================
function drawHeavy3DSilk() {
  noFill();
  // Purposefully lowered the step rate (h+=1) to render all history, increasing computation
  for (let h = 0; h < ribbonHistory.length; h += 1) {
    let snapshot = ribbonHistory[h];
    let ageRatio = h / ribbonHistory.length; 
    let alphaFade = pow(ageRatio, 2.0); 

    push();
    blendMode(SCREEN); 
    
    // Forcefully offset the same trajectory 3 times to create a false sense of volume
    for(let offset = -2; offset <= 2; offset += 2) {
      beginShape();
      for (let i = 0; i < NUM_NODES; i++) {
        let p = snapshot.points[i];
        let hueVal = (snapshot.t * 2 + i * 18) % 360;
        stroke(hueVal, 90, 100, alphaFade * 0.15); 
        strokeWeight(map(alphaFade, 0, 1, 1, 8));
        curveVertex(p.x + offset * 5, p.y + offset * 5); 
        if (i === 0 || i === NUM_NODES - 1) curveVertex(p.x + offset * 5, p.y + offset * 5);
      }
      endShape();
    }
    pop();
  }
}

// ==========================================
// Modification 3: Highly resource-intensive Endpoint Rendering
// ==========================================
function drawComplexEndpoints() {
  push();
  blendMode(ADD);
  
  // 1. Left Hand: Complex multi-layered geometry (Size controlled by leftRadius)
  let hLeft = (frameCount * 2) % 360;
  push();
  translate(leftX, leftY);
  rotate(frameCount * 0.05);
  for(let i = 0; i < leftRadius; i += 5) {
    noFill();
    stroke(hLeft, 80, 100, 0.3);
    strokeWeight(1);
    // Dense nested wireframes
    ellipse(0, 0, i * 1.5, i * 0.8);
    ellipse(0, 0, i * 0.8, i * 1.5);
  }
  fill(hLeft, 100, 100, 0.8);
  noStroke();
  ellipse(0, 0, leftRadius * 0.2);
  pop();

  // 2. Right Hand: Extremely high-frequency nested radial glow (Layers controlled by rightGlowLayers)
  let hRight = (frameCount * 3 + 180) % 360;
  noStroke();
  let maxLayers = floor(rightGlowLayers); // Can reach up to 250 layers
  
  // This loop severely consumes GPU/CPU rendering channels
  for(let r = maxLayers; r > 0; r -= 1) {
    fill(hRight, 90, 100, map(r, maxLayers, 0, 0.005, 0.15));
    // Added jitter noise to force larger redraw areas per frame
    let jitterX = rightX + random(-1, 1);
    let jitterY = rightY + random(-1, 1);
    ellipse(jitterX, jitterY, r * 2.5);
  }
  fill(0, 0, 100, 0.9);
  ellipse(rightX, rightY, 15);
  pop();
}

function drawUI() {
  push();
  fill(0, 0, 100, 0.8); 
  noStroke();
  textAlign(LEFT);
  textSize(14);
  // Removed Chinese characters to ensure universal readability
  text("DIMENSION OF ECHOES (ITERATION 2)", 40, 50);
  text("LEFT HAND: SPREAD TO ENLARGE RADIUS", 40, 70);
  text("RIGHT HAND: SPREAD TO INCREASE GLOW LAYERS (LAG WARNING)", 40, 90);
  
  // Display real-time frame rate to highlight the performance drop
  fill(frameCount % 10 < 5 ? color(0, 100, 100) : color(0, 0, 100)); // Flashing warning
  text(`FPS: ${floor(frameRate())}`, 40, 110);
  pop();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}