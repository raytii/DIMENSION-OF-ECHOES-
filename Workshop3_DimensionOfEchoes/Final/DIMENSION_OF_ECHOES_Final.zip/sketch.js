/**
 * Sketch 3: Dimension of Echoes (Bodies & Machine Seeing)
 * Author: Raytii Jiang
 * Description: A split-screen interactive sketch using ml5.js handPose. 
 * The left screen renders a generative "ether silk" driven by physical hand tracking.
 * The right screen displays the machine's viewpoint (webcam) with an interactive darkness slider.
 */

let handPose;
let video;
let hands = [];

// Canvas and Proportions
let leftScreen, rightScreen;
let viewW, viewH;
let darknessSlider; // Slider to control the camera mask opacity

// Artistic Parameters
let nodes = [];
const NUM_NODES = 25; 
let ribbonHistory = []; 
const MAX_HISTORY = 180; 

// Coordinate smoothing (lerp targets)
let leftX = 0, leftY = 0, rightX = 0, rightY = 0;

function preload() {
  // Initialize the handPose model
  handPose = ml5.handPose();
}

function setup() {
  calculateSizes(); 
  
  // Leave vertical space for the bottom UI and slider
  createCanvas(viewW * 2 + 20, viewH + 60); 
  
  // Initialize split-screen graphics buffers
  leftScreen = createGraphics(viewW, viewH);
  rightScreen = createGraphics(viewW, viewH);
  
  // Create UI Slider: min 0, max 255, default 210 (very dark)
  darknessSlider = createSlider(0, 255, 210);
  darknessSlider.addClass('p5-slider');
  darknessSlider.position(width / 2 - 100, height - 35);

  // Setup webcam capture
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide(); // Hide the default HTML video element

  // Start hand detection
  handPose.detectStart(video, (results) => {
    hands = results;
  });

  // Initialize physical nodes for the ribbon
  for (let i = 0; i < NUM_NODES; i++) {
    nodes.push({ x: viewW / 2, y: viewH / 2 });
  }
  
  // Use HSB color mode for smoother gradient transitions on the art screen
  leftScreen.colorMode(HSB, 360, 100, 100, 1);
}

function calculateSizes() {
  // Goal: Arrange two 16:9 rectangles horizontally, scaling to fit the window
  let margin = 40;
  let availableW = (windowWidth - margin) / 2;
  let availableH = windowHeight - 100;

  viewW = availableW;
  viewH = viewW * (9/16);

  // Recalculate if the height exceeds the window space
  if (viewH > availableH) {
    viewH = availableH;
    viewW = viewH * (16/9);
  }
}

function draw() {
  background(0); 
  
  updateHandInput();
  updatePhysics();

  // Record node positions for the ribbon history trail
  let currentSnap = [];
  for (let n of nodes) {
    currentSnap.push({x: n.x, y: n.y}); 
  }
  ribbonHistory.push({points: currentSnap, t: frameCount});
  
  if (ribbonHistory.length > MAX_HISTORY) {
    ribbonHistory.shift();
  }

  // Render the two separate buffers
  renderLeftArt();
  renderRightCamera();

  // Draw the buffers onto the main canvas, centered
  let startX = (width - (viewW * 2 + 20)) / 2;
  image(leftScreen, startX, 0);
  image(rightScreen, startX + viewW + 20, 0);
  
  drawStaticUI();
}

function updateHandInput() {
  // Differentiate left and right hands
  let rawLeft = hands.find(h => h.handedness === 'Right'); 
  let rawRight = hands.find(h => h.handedness === 'Left');

  // Map index finger (keypoint 8) to canvas coordinates with linear interpolation (lerp) for smoothness
  if (rawLeft) {
    let tx = map(rawLeft.keypoints[8].x, 0, video.width, viewW, 0);
    let ty = map(rawLeft.keypoints[8].y, 0, video.height, 0, viewH);
    leftX = lerp(leftX, tx, 0.15);
    leftY = lerp(leftY, ty, 0.15);
  }
  if (rawRight) {
    let tx = map(rawRight.keypoints[8].x, 0, video.width, viewW, 0);
    let ty = map(rawRight.keypoints[8].y, 0, video.height, 0, viewH);
    rightX = lerp(rightX, tx, 0.15);
    rightY = lerp(rightY, ty, 0.15);
  }
}

function updatePhysics() {
  // Anchor the ends of the ribbon to the fingers
  nodes[0].x = leftX;
  nodes[0].y = leftY;
  nodes[NUM_NODES - 1].x = rightX;
  nodes[NUM_NODES - 1].y = rightY;

  // Apply spring-like physics and perlin noise to intermediate nodes
  for (let i = 1; i < NUM_NODES - 1; i++) {
    let targetX = (nodes[i - 1].x + nodes[i + 1].x) / 2;
    let targetY = (nodes[i - 1].y + nodes[i + 1].y) / 2;
    let n = noise(i * 0.3, frameCount * 0.02) * 8;
    nodes[i].x = lerp(nodes[i].x, targetX, 0.2) + (n - 4);
    nodes[i].y = lerp(nodes[i].y, targetY, 0.2) + (n - 4);
  }
}

function renderLeftArt() {
  leftScreen.background(0);
  leftScreen.noFill();
  
  // Draw the generative silk from history
  for (let h = 0; h < ribbonHistory.length; h += 3) {
    let snapshot = ribbonHistory[h];
    let ageRatio = h / ribbonHistory.length; 
    let alphaFade = pow(ageRatio, 2.2); // Exponential decay for natural fading

    leftScreen.push();
    leftScreen.blendMode(SCREEN);
    leftScreen.beginShape();
    for (let i = 0; i < NUM_NODES; i++) {
      let p = snapshot.points[i];
      let hueVal = (snapshot.t * 2 + i * 18) % 360;
      leftScreen.stroke(hueVal, 95, 85, alphaFade * 0.4); 
      leftScreen.strokeWeight(map(alphaFade, 0, 1, 0.5, 5));
      leftScreen.curveVertex(p.x, p.y);
      if (i === 0 || i === NUM_NODES - 1) leftScreen.curveVertex(p.x, p.y);
    }
    leftScreen.endShape();
    leftScreen.pop();
  }
  
  // Render glowing core nodes
  renderCores(leftScreen, leftX, leftY);
  renderCores(leftScreen, rightX, rightY);
}

function renderRightCamera() {
  rightScreen.push();
  // Mirror the camera feed for intuitive interaction
  rightScreen.translate(viewW, 0);
  rightScreen.scale(-1, 1);
  
  // Base video rendering with gray filter
  rightScreen.tint(180); 
  rightScreen.image(video, 0, 0, viewW, viewH);
  rightScreen.filter(GRAY);
  
  // Dynamic darkness mask controlled by the UI slider
  let darkness = darknessSlider.value();
  rightScreen.fill(0, darkness); 
  rightScreen.noStroke();
  rightScreen.rect(0, 0, viewW, viewH);
  rightScreen.pop();
  
  // Draw guiding points over the camera feed
  rightScreen.fill(255, 150);
  rightScreen.noStroke();
  rightScreen.ellipse(leftX, leftY, 8);
  rightScreen.ellipse(rightX, rightY, 8);
}

function renderCores(pg, x, y) {
  pg.push();
  pg.blendMode(ADD);
  let h = (frameCount * 2.5) % 360;
  for(let r = 30; r > 0; r -= 6) {
    pg.fill(h, 90, 100, map(r, 30, 0, 0.02, 0.45));
    pg.ellipse(x, y, r);
  }
  pg.fill(0, 0, 100, 0.9);
  pg.ellipse(x, y, 6);
  pg.pop();
}

function drawStaticUI() {
  fill(255, 100);
  noStroke();
  textSize(12);
  textAlign(CENTER);
  text("ETHER GENESIS", viewW / 2, viewH + 20);
  text("PHYSICAL OBSERVER", viewW + 20 + viewW / 2, viewH + 20);
  text("CAMERA DARKNESS CONTROL", width / 2, height - 45);
}

function windowResized() {
  calculateSizes();
  resizeCanvas(viewW * 2 + 20, viewH + 60);
  // Reposition UI elements dynamically
  darknessSlider.position(width / 2 - 100, height - 35);
  // Recreate buffers to match new window size
  leftScreen = createGraphics(viewW, viewH);
  rightScreen = createGraphics(viewW, viewH);
  leftScreen.colorMode(HSB, 360, 100, 100, 1);
}